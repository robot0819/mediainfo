#!/bin/bash
# ============ 用户配置 ============
# Telegram 配置
TG_BOT_TOKEN="YOUR_BOT_TOKEN_HERE"
TG_CHAT_ID="YOUR_CHAT_ID_HERE"

# 路径配置
SCREENSHOT_ROOT="/var/screenshot"
HOME_DOWNLOADS="/home/yuyehd/qbittorrent/Downloads"

# 截图配置
PICS=6
MAX_SIZE_KB=9500  # 9.5MB，Pixhost限制10MB
# ==================================
