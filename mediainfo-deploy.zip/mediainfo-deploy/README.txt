MediaInfo 截图工具 - 部署包
==============================

功能：
- 自动截取视频截图 (PNG格式)
- nconvert压缩，超10MB自动转JPG
- 上传到Pixhost图床
- 生成MediaInfo/BDInfo报告
- Telegram通知
- qBittorrent集成

安装：
  sudo bash install.sh

配置Telegram：
  nano /usr/local/etc/mediainfo/config.sh

qBittorrent设置：
  设置 -> 下载 -> 完成时运行外部程序:
  sudo /usr/local/bin/bdscan "%F"

手动运行：
  /usr/local/bin/bdscan /path/to/video
  sudo /usr/local/bin/bdscan /path/to/file.iso

文件说明：
  bin/screenshot.sh  - 核心截图脚本
  bin/bdscan         - 调度脚本(ISO挂载)
  bin/bdinfo         - BDInfo Docker封装
  bin/nconvert       - PNG压缩工具
  config/config.sh   - 用户配置文件
  install.sh         - 安装脚本
