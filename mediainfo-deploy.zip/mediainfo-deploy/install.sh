#!/bin/bash
# MediaInfo Deploy - 一键安装脚本
# 适用于 Ubuntu/Debian

set -e

echo "======================================"
echo "  MediaInfo 截图工具 - 安装脚本"
echo "======================================"

# 检查root权限
if [[ "$EUID" -ne 0 ]]; then
    echo "请使用 sudo 运行此脚本"
    exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# 1. 安装依赖
echo ""
echo "[1/4] 安装系统依赖..."
apt update
apt install -y ffmpeg mediainfo curl jq coreutils

# 2. 检查Docker并拉取BDInfo镜像
echo ""
echo "[2/4] 配置BDInfo..."
if command -v docker &>/dev/null; then
    echo "拉取BDInfo Docker镜像..."
    docker pull fr3akyphantom/bdinfocli-ng || true
else
    echo "Docker未安装，跳过BDInfo配置（可选功能）"
fi

# 3. 复制脚本文件
echo ""
echo "[3/4] 安装脚本文件..."
cp "${SCRIPT_DIR}/bin/screenshot.sh" /usr/local/bin/
cp "${SCRIPT_DIR}/bin/bdscan" /usr/local/bin/
cp "${SCRIPT_DIR}/bin/bdinfo" /usr/local/bin/
cp "${SCRIPT_DIR}/bin/nconvert" /usr/local/bin/

chmod +x /usr/local/bin/screenshot.sh
chmod +x /usr/local/bin/bdscan
chmod +x /usr/local/bin/bdinfo
chmod +x /usr/local/bin/nconvert

# 创建配置目录和文件
mkdir -p /usr/local/etc/mediainfo
cp "${SCRIPT_DIR}/config/config.sh" /usr/local/etc/mediainfo/

# 创建截图输出目录
mkdir -p /var/screenshot
chmod 777 /var/screenshot

# 4. 配置sudo免密
echo ""
echo "[4/4] 配置权限..."

ACTUAL_USER="${SUDO_USER:-$USER}"
if [[ "$ACTUAL_USER" != "root" ]]; then
    SUDOERS_LINE="$ACTUAL_USER ALL=(ALL) NOPASSWD: /usr/local/bin/bdscan"
    SUDOERS_FILE="/etc/sudoers.d/mediainfo"

    if [[ ! -f "$SUDOERS_FILE" ]] || ! grep -q "bdscan" "$SUDOERS_FILE" 2>/dev/null; then
        echo "$SUDOERS_LINE" > "$SUDOERS_FILE"
        chmod 440 "$SUDOERS_FILE"
        echo "已添加sudo免密配置: $ACTUAL_USER"
    fi
fi

echo ""
echo "======================================"
echo "  安装完成!"
echo "======================================"
echo ""
echo "接下来请："
echo ""
echo "1. 编辑配置文件，填入Telegram信息："
echo "   nano /usr/local/etc/mediainfo/config.sh"
echo ""
echo "2. 在qBittorrent中配置："
echo "   设置 -> 下载 -> Torrent完成时运行外部程序："
echo "   sudo /usr/local/bin/bdscan \"%F\""
echo ""
echo "3. 测试运行："
echo "   /usr/local/bin/bdscan /path/to/video.mkv"
echo ""
